from . import base, doclevel, gazetteers, heuristics, aggregation, utils, spacy, voting, generative
__version__ = "0.3.2"
